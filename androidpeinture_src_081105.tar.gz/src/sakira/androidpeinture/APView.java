package sakira.androidpeinture;

//import java.util.Vector;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class APView extends View {

	int _layer_index;
	int _x0, _y0, _x1, _y1;
	int _width, _height;
	int _zoom, _shift_x, _shift_y;
	int _mode;
    Bitmap _bitmap = null;
    Bitmap _bitmap_p, _bitmap_t, _bitmap565;
	Bitmap[] _layers;
	Paint _paint;
	
	static final int DRAW_MODE = 1;
	static final int COLOR_PICK_MODE = 2;

    static final int LayerNumber = 3;
    
    static final int PenWidthMax = 50;
	
    public APView(Context context) {
    	super(context);
    	setup();
    }
    
	public APView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setup();
	}
	
	public APView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		setup();
	}
	
	void setup() {
		_x0 = _y0 = -1;
		_layer_index = 0;
		_mode = DRAW_MODE;
		
		_bitmap = _bitmap_p = _bitmap_t = null;
		_bitmap565 = null;
		_paint = new Paint();
		_paint.setColor(0x80ff0000);
		_paint.setStrokeWidth(10);
		_paint.setStrokeJoin(Paint.Join.ROUND);
		_paint.setStrokeCap(Paint.Cap.ROUND);
		
		_zoom = _shift_x = _shift_y = 0;
	}
	
    void start(int w, int h) {
	clear_buf(w, h);
    }
    
    int getPenWidth() {
    	return (int)_paint.getStrokeWidth();
    }
    
    void setPenWidth(int w) {
    	_paint.setStrokeWidth(w);
    }
    
    int getPenDensity() {
    	return (int)_paint.getAlpha();
    }
    
    void setPenDensity(int w) {
    	_paint.setAlpha(w);
    }
	
    int getPenColor() {
    	return _paint.getColor();
    }
    
    void setPenColor(int c) {
    	_paint.setColor((_paint.getColor() & 0xff000000) |
    			(c & 0x00ffffff));
    }
    
    void setMode(int m) {
    	_mode = m;
    }
    
    void clear_buf(int w, int h) {
	_width = w;
	_height = h;

		_layers = new Bitmap[LayerNumber];
		for (int i = 0; i < LayerNumber; i ++) {
		    _layers[i] =  Bitmap.createBitmap(_width, _height, 
				Bitmap.Config.ARGB_8888);
		    _layers[i].eraseColor(0xffffffff);
		}

		_bitmap = Bitmap.createBitmap(_width, _height, 
				Bitmap.Config.ARGB_8888);
		_bitmap_p = Bitmap.createBitmap(_width, _height, 
				Bitmap.Config.ARGB_8888);
		_bitmap_t = Bitmap.createBitmap(_width, _height, 
				Bitmap.Config.ARGB_8888);
		_bitmap565 = Bitmap.createBitmap(2, 2,
				Bitmap.Config.RGB_565);

		apply_layers(new Rect(0, 0, _width - 1, _height -1));
		clear_pen_layer();
		
		invalidate();
	}
	
    void apply_layers(Rect rect) {
	Canvas cl = new Canvas(_layers[_layer_index]);
	cl.drawBitmap(_bitmap_t, rect, rect, null);
	Paint p = new Paint();
	p.setAlpha(_paint.getAlpha());
	cl.drawBitmap(_bitmap_p, rect, rect, p);

	Xfermode mult_xfer = new PorterDuffXfermode(
				PorterDuff.Mode.MULTIPLY);
	Paint mult_p = new Paint();
	mult_p.setXfermode(mult_xfer);
		
	Canvas canvas = new Canvas(_bitmap);
	canvas.drawBitmap(_layers[0], rect, rect, null);
	for (int i = 1; i < LayerNumber; i ++)
	    canvas.drawBitmap(_layers[i], rect, rect, mult_p);
    }
	
    void apply_pen_layer() {
	Canvas cl = new Canvas(_layers[_layer_index]);
	cl.drawBitmap(_bitmap_t, 0, 0, null);
	Paint p = new Paint();
	p.setAlpha(_paint.getAlpha());
	cl.drawBitmap(_bitmap_p, 0, 0, p);

//	Canvas ct = new Canvas(_bitmap_t);
//	ct.drawBitmap(_layers[_layer_index], 0, 0, null);
    }

    void clear_pen_layer() {
	_bitmap_p.eraseColor(0);
	Canvas c = new Canvas(_bitmap_t);
	c.drawBitmap(_layers[_layer_index], 0, 0, null);
    }
    
    void change_layer(int l) {
    	if (l >= LayerNumber || l < 0) return;
    	
    	apply_pen_layer();
    	_layer_index = l;
    	clear_pen_layer();
    }
	
    public void drawLine(int ox0, int oy0, int ox1, int oy1) {
	int x0 = _shift_x + (ox0 >> _zoom);
	int y0 = _shift_y + (oy0 >> _zoom);
	int x1 = _shift_x + (ox1 >> _zoom);
	int y1 = _shift_y + (oy1 >> _zoom);
 		
	Canvas c = new Canvas(_bitmap_p);
	Paint p = new Paint(_paint);
	p.setAlpha(0xff);
	c.drawLine(x0, y0, x1, y1, p);
    }
	
	void touchPressed(int x, int y) {
		_x0 = x;
		_y0 = y;
	}
	
	void touchDragged(int x, int y) {
		if (_x0 < 0) return;
		
		int pen_width = (int)_paint.getStrokeWidth();
		int pwh = (pen_width / 2 + 1);
		
		_x1 = _x0; _y1 = _y0;
		_x0 =   x; _y0 =   y;
		int min_x = Math.min(_x0, _x1) - pwh;
		int max_x = Math.max(_x0, _x1) + pwh;
		int min_y = Math.min(_y0, _y1) - pwh;
		int max_y = Math.max(_y0, _y1) + pwh;
		
		drawLine(_x0, _y0, _x1, _y1);
		Rect r = new Rect(min_x, min_y,max_x, max_y);
		apply_layers(r);
		invalidate(r);
	}
	
	void touchReleased(int x, int y) {
		apply_pen_layer();
		clear_pen_layer();
		_x0 = _y0 = _x1 = _y1 = -1;
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
	    if (_bitmap == null) return false;

	    int x = (int)event.getX();
	    int y = (int)event.getY();
	    
	    if (_mode == DRAW_MODE) {
	    	switch (event.getAction()) {
	    	case MotionEvent.ACTION_DOWN:
			touchPressed(x, y);
			break;
	    	case MotionEvent.ACTION_MOVE:
			touchDragged(x, y);
			break;
	    	case MotionEvent.ACTION_UP:
			touchReleased(x, y);
			break;
	    	}	
	    } else if (_mode == COLOR_PICK_MODE) {
	    	switch (event.getAction()) {
	    	case MotionEvent.ACTION_DOWN:
	    	case MotionEvent.ACTION_MOVE:
	    		Canvas c = new Canvas(_bitmap565);
	    		c.drawBitmap(_bitmap, 
	    				new Rect(x, y, x + 1, y + 1),
	    				new Rect(0, 0, 1, 1),
	    				null);
	    		int pc = _bitmap565.getPixel(0, 0);
	    		setPenColor(pc);
	    		androidpeinture._color_btn.setTextColor(pc);
	    		break;
	    	case MotionEvent.ACTION_UP:
		    	_mode = DRAW_MODE;
		    	break;
	    	}
	    }
	    return true;
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		
		if (_bitmap != null)
			canvas.drawBitmap(_bitmap, 0, 0, null);
	}

}
