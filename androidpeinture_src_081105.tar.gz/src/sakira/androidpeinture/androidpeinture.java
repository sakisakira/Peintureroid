package sakira.androidpeinture;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.util.DisplayMetrics;

public class androidpeinture extends Activity {
    int _height, _width;
    APView _view;
    static public Button _layer_btn, _width_btn, _color_btn, _density_btn;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        _height = dm.heightPixels;
        _width = dm.widthPixels;

        setContentView(R.layout.main);
        _view = (APView) findViewById(R.id.apview);
        _view.start(_width, _height);

        _layer_btn = (Button)findViewById(R.id.layer_button);
        _layer_btn.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		showLayerButtons();
        	}
        });

        _width_btn = (Button)findViewById(R.id.width_button);
        _width_btn.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		showWidthSlider();
        	}
        });

        _color_btn = (Button)findViewById(R.id.color_button);
        _color_btn.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		showRGBSlider();
        	}
        });

        _density_btn = (Button)findViewById(R.id.density_button);
        _density_btn.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		showDensitySlider();
        	}
        });

        
    }

    LinearLayout clearOptionalControls() {
    	LinearLayout l = (LinearLayout) findViewById(R.id.optional_controls);
    	if (l.getChildCount() > 0)
    		l.removeAllViews();
    	return l;
    }
    
    void showLayerButtons() {
    	final LinearLayout l = clearOptionalControls();	
    	
    	for (int i = 0; i < APView.LayerNumber; i ++) {
    		Button b = new Button(this);
    		b.setText("Layer:" + i);
    		l.addView(b);
    	    b.setOnClickListener(new View.OnClickListener() {
    	    	public void onClick(View v) {
    	    		Button b = (Button)v;
    	    		_view.change_layer(l.indexOfChild(v));
    	    		_layer_btn.setText(b.getText());
    	    		l.removeAllViews();
    	    	}
    	    });
    	}
    }
    
    void showWidthSlider() {
    	final LinearLayout l = clearOptionalControls();
    	final TextView title = new TextView(this);

    	int pw = _view.getPenWidth();
    	title.setText("Pen Width = " + pw);
    	l.addView(title);
    	SeekBar slider = new SeekBar(this);
    	slider.setMax(APView.PenWidthMax);
    	slider.setProgress(pw);
    	l.addView(slider);
    	slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromTouch) {
				progress = Math.max(1, progress);
				title.setText("Pen Width = " + progress);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {}
			public void onStopTrackingTouch(SeekBar seekBar) {
				int progress = seekBar.getProgress(); 
				_view.setPenWidth(progress);
				_width_btn.setText("Width:" + progress);
				l.removeAllViews();
			}
    	});
    }

    void showRGBSlider() {
    	final LinearLayout l = clearOptionalControls();
    	final TextView title = new TextView(this);

    	int pc = _view.getPenColor() | 0xff000000;
    	title.setText("set Red, Green, and Blue");
    	title.setTextColor(pc);
    	l.addView(title);
    	final SeekBar rslider = new SeekBar(this);
    	rslider.setMax(0xff);
    	rslider.setProgress((pc & 0xff0000) >> 16);
    	l.addView(rslider);
    	final SeekBar gslider = new SeekBar(this);
    	gslider.setMax(0xff);
    	gslider.setProgress((pc & 0xff00) >> 8);
    	l.addView(gslider);
    	final SeekBar bslider = new SeekBar(this);
    	bslider.setMax(0xff);
    	bslider.setProgress((pc & 0xff));
    	l.addView(bslider);
    	
        SeekBar.OnSeekBarChangeListener RGBlister =
        	new SeekBar.OnSeekBarChangeListener() {
    		public void onProgressChanged(SeekBar seekBar, int progress,
    				boolean fromTouch) {
    			int pc = 0xff000000 |
    				(rslider.getProgress() << 16) |
    				(gslider.getProgress() << 8) |
    				(bslider.getProgress());
    			title.setTextColor(pc);
    		}
    		public void onStartTrackingTouch(SeekBar seekBar) {}
    		public void onStopTrackingTouch(SeekBar seekBar) {}
        };
        rslider.setOnSeekBarChangeListener(RGBlister);
        gslider.setOnSeekBarChangeListener(RGBlister);
        bslider.setOnSeekBarChangeListener(RGBlister);
        
        Button ok_btn = new Button(this);
        ok_btn.setText("OK");
        l.addView(ok_btn);
	    ok_btn.setOnClickListener(new View.OnClickListener() {
	    	public void onClick(View v) {
    			int pc = (0xff000000) |
				(rslider.getProgress() << 16) |
				(gslider.getProgress() << 8) |
				(bslider.getProgress());
	    		_view.setPenColor(pc);
	    		l.removeAllViews();
	    		_color_btn.setTextColor(pc);
	    	}
	    });
	    
     	Button picker_btn = new Button(this);
        picker_btn.setText("Color Picker");
        l.addView(picker_btn);
        picker_btn.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		_view.setMode(APView.COLOR_PICK_MODE);
        		l.removeAllViews();
		    	}
		    });
    }


    void showDensitySlider() {
    	final LinearLayout l = clearOptionalControls();
    	final TextView title = new TextView(this);

    	int pd = _view.getPenDensity();
    	title.setText("Pen Density = " + String.format("%.2f", pd/255.0));
    	l.addView(title);
    	SeekBar slider = new SeekBar(this);
    	slider.setMax(0xff);
    	slider.setProgress(pd);
    	l.addView(slider);
    	slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromTouch) {
				title.setText("Pen Density = " + 
						String.format("%.2f", progress/255.0)); 
			}
			public void onStartTrackingTouch(SeekBar seekBar) {}
			public void onStopTrackingTouch(SeekBar seekBar) {
				int progress = seekBar.getProgress(); 
				_view.setPenDensity(progress);
				_density_btn.setText("Density:" +
						String.format("%.2f", progress/255.0)); 
				l.removeAllViews();
			}
    	});
    }

}